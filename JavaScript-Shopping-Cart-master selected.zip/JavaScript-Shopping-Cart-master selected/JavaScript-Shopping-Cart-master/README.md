A javascript application for shopping cart which can add and delete items for the cart and update the total amount in the cart.

Credit : https://github.com/john-smilga/js-cart-setup


